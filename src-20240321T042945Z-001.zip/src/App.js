import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import Home_Page from './Home_Page';
import User_Page from './User_Page';
import Consult_Page from './Consult_Page';


const App = () => { 
  return (
    <Router>
      <Routes>
        <Route path ="/" element={<Home_Page/>}/>
        <Route path ="/User_Page" element={<User_Page/>}/>
        <Route path = "/Consult_Page" element = {<Consult_Page/>}/> 
      </Routes>
    </Router>
  );
}

export default App;


