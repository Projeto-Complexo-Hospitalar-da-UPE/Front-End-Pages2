import React, { useState } from 'react';

function Name_Box() {
    const [selectedValue, setSelectedValue] = useState('');
    
    const handleSelectChange = (event) => {
        setSelectedValue(event.target.value);
    };
    
    return (
        <div>
        <h2>Selecione uma opção:</h2>
        <select value={selectedValue} onChange={handleSelectChange}>
            <option value="">Selecione...</option>
            <option value="opcao1">Opção 1</option>
            <option value="opcao2">Opção 2</option>
            <option value="opcao3">Opção 3</option>
        </select>
        <p>Você selecionou: {selectedValue}</p>
        </div>
    );
    }
export default Name_Box;
