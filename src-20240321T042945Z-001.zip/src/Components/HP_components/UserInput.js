function UserInput() {
    return (
        <div>
            <input type="text" className="UsrInpt" userid ="User Identification" placeholder="Usuário"/> 
        </div>  
    );
}

export default UserInput