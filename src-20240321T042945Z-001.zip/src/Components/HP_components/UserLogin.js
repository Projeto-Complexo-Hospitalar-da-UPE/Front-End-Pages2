const UserLogin = () => {
    return (
      <label>
        <input type="text" className = "UsrLgn" placeholder="Login" />
      </label>
    );
}
export default UserLogin