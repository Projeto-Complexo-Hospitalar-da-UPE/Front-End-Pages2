import { Link } from "react-router-dom";
import Consult_Page from "../../Consult_Page";

const Consult_Button = () => {
    return(
      <div>
       <Link to="Consult_Page">
          <button className="ConsultButton" > Consultar Exame </button>
       </Link>
      </div>
    );
};
export default Consult_Button;



