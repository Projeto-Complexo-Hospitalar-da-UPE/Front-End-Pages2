import { Link } from "react-router-dom";

const Regist_Button = () => {
    return(
      <div>
        <Link to="/" >
          <button className="Regist_Button"> Registrar Exame </button>
        </Link>
      </div>
    );
};

export default Regist_Button;