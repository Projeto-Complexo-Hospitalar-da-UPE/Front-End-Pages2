import React from 'react';
import './index_Consult_Page.css';
import Date_Picker from './Components/EP_components/Date_Picker';
import Return_Button from './Components/EP_components/Return_Button';
import Name_Box from './Components/EP_components/Name_Box';


function Consult_Page() {


    const Tittle = "Consultar Exames"

    return (
        
      <div className="Center2">
        <div className="Bar2"></div>
        <h1>emirwvgw7yng</h1>
        <div className= 'container_Exam_Icons'>
          <img className= 'Consult_Icon' src = "./Images_Folder/UP_png/Consult_Icon.png"></img>
          <img className= 'Regist_Icon' src = "./Images_Folder/UP_png/Regist_Icon.png"></img>
        </div>
  
  
        <div className='container_Bar_Icons_CP'>
            <img className = "UPE_logo_UP" src = "./Images_Folder/Logo-upe-site.png"></img>
            <img className = "SCH_UP" src = "./Images_Folder/sch.png"></img>
              <div className='container_Icon_Name'>
                <h1 className= "Text"> {Tittle} </h1>
                <img className= 'Doc_Icon' src = "./Images_Folder/UP_png/User_Doctor.png"></img>
              </div>
        </div>

          <Name_Box/>
          <Date_Picker/>
          <Return_Button/>
          
      </div>
     
  
    );
};

export default Consult_Page;