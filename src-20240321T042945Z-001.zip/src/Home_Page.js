import React from 'react';
import './index_Home_Page.css';
import UserInput from './Components/HP_components/UserInput'
import UserLogin from './Components/HP_components/UserLogin'
import EnterButton from './Components/HP_components/EnterButton'



function Home_page() {

    const UPE = "Universidade de Pernambuco"
    const Poli = "Escola Politécnica de Pernambuco"
    
    return (
      <div className="Center">
        <div className="Blur"></div>
  
        <img className = "SCH_HP" src = "./Images_Folder/sch.png" alt=""></img>
  
        <div className= 'container_Login_Icon'>
          <img className= 'User_icon' src = "./Images_Folder/HP_png/User_png.png" alt=""></img>
          <img className= 'Login_icon' src = "./Images_Folder/HP_png/Login_png.png" alt=""></img>
        </div>
  
  
        <div className='container_UPE_content'>
          <p className='UPE_text'> {UPE} </p>
          <img className = "UPE_logo" src = "./Images_Folder/Logo-upe-site.png" alt=""></img>
        </div>
        
        <div className='container_Poli_content'>
          <p className='Poli_text'> {Poli} </p> 
          <img className= 'Poli_logo' src = "./Images_Folder/Poliupe.png" alt=""></img>
        </div>
          <UserInput/>
          <UserLogin/>
          <EnterButton/>
      </div>
  
    );
};

export default Home_page;